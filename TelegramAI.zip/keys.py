# Конфигурация News
api_key_news = '43324d4e1bd0464894ca119e029c70b1'

# Конфигурация Bybit API
api_key_bybit = 'StWLfbbOf09GIpsjto'  # Вставь свой API ключ
api_secret_bybit = '1X8yWl3zg7DQdgkAcXLgjfPs0eFErpoVtE5E'  # Вставь свой API секрет

# Конфигурация CoinMarketCap API
cmc_api_key = '9d6e4a1e-f4e1-44fd-9b73-26e59513ef71'  # Вставь свой API ключ

# Конфигурация Twitter API
twitter_bearer_token = 'AAAAAAAAAAAAAAAAAAAAAImOyAEAAAAAYnLPicjxHh3iRdG%2FuGQ9cbim%2Fik%3D2tuyORQAwhEaSpLNRhTqbJpy8RUlhWTObhuXmEBaf8qWn2X2tN'

# Telegram конфигурация (для публичных групп)
telegram_bot_token = '7540566123:AAFiQ3HXVdrsRDOukw81JoR8hSfM6vRHBso'
telegram_chat_id = '@cryptonatedai'

# Конфигурация CryptoPanic
cryptopanic_api_key = '0abe77b16a8071ad090670323a6bd1a0f0daf4a1'
