import requests
from db_manager import insert_price_data
from logger import logger


class CoinGeckoService:
    def __init__(self):
        self.success_count = 0
        self.error_count = 0

    def make_request(self, url, params=None):
        """
        Отправка GET запроса к API CoinGecko.
        """
        try:
            response = requests.get(url, params=params)
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Ошибка при запросе к CoinGecko: {response.status_code}")
        except Exception as e:
            logger.error(f"Ошибка при отправке запроса: {e}")
        return None

    def fetch_and_save_data(self):
        """
        Сбор данных с CoinGecko и сохранение в базу данных.
        """
        logger.info("Начинаем сбор данных для топ-100 криптовалют с CoinGecko.")
        page = 1
        per_page = 100

        while True:
            response = self.make_request(f"https://api.coingecko.com/api/v3/coins/markets",
                                         params={"vs_currency": "usd", "page": page, "per_page": per_page})

            if not response or "data" not in response:
                logger.error(f"Не удалось получить данные для страницы {page}.")
                self.error_count += 1
                break

            for coin in response["data"]:
                try:
                    symbol = coin.get("symbol")
                    last_price = coin.get("current_price")
                    high_price = coin.get("high_24h")
                    low_price = coin.get("low_24h")
                    open_price = 0  # CoinGecko не предоставляет цену открытия

                    # Логируем данные перед их вставкой
                    logger.debug(f"Вставляем данные: {symbol}, {last_price}, {high_price}, {low_price}, {open_price}")

                    insert_price_data("CoinGecko", symbol, last_price, high_price, low_price, open_price)

                    self.success_count += 1

                except Exception as e:
                    logger.error(f"Ошибка при обработке данных для {coin.get('symbol')}: {e}")
                    self.error_count += 1

            if len(response["data"]) < per_page:
                break

            page += 1

        logger.info(
            f"Сбор данных завершён. Успешно обработано {self.success_count} записей, с ошибками {self.error_count}.")
