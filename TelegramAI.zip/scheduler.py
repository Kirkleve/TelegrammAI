from services.news_service import NewsService
from services.coinmarketcap_service import CoinMarketCapService
from services.bybit_service import BybitService
from services.coingecko_service import CoinGeckoService
from services.cryptopanic_service import CryptoPanicService
import schedule
import time

# Create service instances
news_service = NewsService()
bybit_service = BybitService()
coingecko_service = CoinGeckoService()
coinmarketcap_service = CoinMarketCapService()
cryptopanic_service = CryptoPanicService()

# Job function to fetch data from all services
def job():
    try:
        news_service.fetch_and_save_data()
    except Exception as e:
        print(f"Error fetching data from NewsService: {e}")

    try:
        bybit_service.fetch_and_save_data()
    except Exception as e:
        print(f"Error fetching data from BybitService: {e}")

    try:
        coingecko_service.fetch_and_save_data()
    except Exception as e:
        print(f"Error fetching data from CoinGeckoService: {e}")

    try:
        coinmarketcap_service.fetch_and_save_data()
    except Exception as e:
        print(f"Error fetching data from CoinMarketCapService: {e}")

    try:
        cryptopanic_service.fetch_and_save_all_data()
    except Exception as e:
        print(f"Error fetching data from CryptoPanicService: {e}")

# Scheduling the job to run every hour
schedule.every(1).minute.do(job)

print("Data collection started...")
while True:
    schedule.run_pending()
    time.sleep(1)

