import sqlite3
import logging

# Настроим логирование для вывода ошибок
logger = logging.getLogger("CryptoLogger")

def create_connection():
    """Создаёт подключение к базе данных"""
    try:
        conn = sqlite3.connect('crypto_data.db')
        return conn
    except sqlite3.Error as e:
        logger.error(f"Ошибка при подключении к базе данных: {e}")
        return None

def create_tables():
    """Создаёт необходимые таблицы, если их нет"""
    conn = create_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS crypto_prices (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT,
                    symbol TEXT,
                    last_price REAL,
                    high_price REAL,
                    low_price REAL,
                    open_price REAL,
                    timestamp TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS crypto_news (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT,
                    title TEXT,
                    description TEXT,
                    url TEXT
                )
            """)
            conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка при создании таблиц: {e}")
        finally:
            conn.close()
    else:
        logger.error("Не удалось создать подключение к базе данных.")

def insert_data(table, data):
    """Вставка данных в таблицу"""
    conn = create_connection()
    if conn:
        try:
            cursor = conn.cursor()
            if table == "crypto_prices":
                cursor.executemany("""
                    INSERT INTO crypto_prices (source, symbol, last_price, high_price, low_price, open_price, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, data)
            elif table == "crypto_news":
                cursor.executemany("""
                    INSERT INTO crypto_news (source, title, description, url)
                    VALUES (?, ?, ?, ?)
                """, data)
            conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка при вставке данных в таблицу {table}: {e}")
        finally:
            conn.close()
    else:
        logger.error(f"Не удалось создать подключение для вставки данных в таблицу {table}.")

def fetch_data(table):
    """Получение данных из таблицы"""
    conn = create_connection()
    if conn:
        try:
            cursor = conn.cursor()
            if table == "crypto_prices":
                cursor.execute("SELECT * FROM crypto_prices")
            elif table == "crypto_news":
                cursor.execute("SELECT * FROM crypto_news")
            return cursor.fetchall()
        except sqlite3.Error as e:
            logger.error(f"Ошибка при извлечении данных из таблицы {table}: {e}")
            return []
        finally:
            conn.close()
    else:
        logger.error(f"Не удалось создать подключение для извлечения данных из таблицы {table}.")
        return []

def update_data(table, data, condition):
    """Обновление данных в таблице"""
    conn = create_connection()
    if conn:
        try:
            cursor = conn.cursor()
            if table == "crypto_prices":
                cursor.execute("""
                    UPDATE crypto_prices
                    SET last_price = ?, high_price = ?, low_price = ?, open_price = ?, timestamp = ?
                    WHERE symbol = ?
                """, (*data, condition))
            elif table == "crypto_news":
                cursor.execute("""
                    UPDATE crypto_news
                    SET title = ?, description = ?, url = ?
                    WHERE id = ?
                """, (*data, condition))
            conn.commit()
        except sqlite3.Error as e:
            logger.error(f"Ошибка при обновлении данных в таблице {table}: {e}")
        finally:
            conn.close()

def delete_data(table, symbol):
    try:
        # Создаем соединение и курсор
        conn = create_connection()
        cursor = conn.cursor()

        # Формируем запрос
        query = f"DELETE FROM {table} WHERE symbol = ?"

        # Печатаем для отладки
        print(f"Executing query: {query} with symbol = {symbol}")

        # Выполняем запрос
        cursor.execute(query, (symbol,))

        # Подтверждаем транзакцию
        conn.commit()

        # Закрываем соединение
        conn.close()
    except Exception as e:
        print(f"Error deleting data: {e}")



